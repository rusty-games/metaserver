import * as wasm from "football-game";

wasm.main();