(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./index.js":
/*!******************!*\
  !*** ./index.js ***!
  \******************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var football_game__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! football-game */ \"../pkg/football_game.js\");\n\n\n//# sourceURL=webpack:///./index.js?");

/***/ })

}]);